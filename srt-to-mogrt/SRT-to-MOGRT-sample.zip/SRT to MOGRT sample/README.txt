SRT to MOGRT - Sample for Reviewers
===================================

Contents
--------
- Sample Template.mogrt   A Premiere Pro-authored template. It has a caption
                          text layer plus a small label element - the panel
                          fills in the caption text and leaves the label as is.
- captions.srt            A short SRT subtitle file (5 cues, English) - for Pro only.

The template uses Arial Black. Tested with Premiere Pro 25.6.6 and 26.3.0
on Windows.

--------------------------------------------------------------------
How to test SRT to MOGRT (Pro)
--------------------------------------------------------------------
1. Open a project that already has a sequence.
2. Section 1: load captions.srt.
3. Section 2: click "Add .mogrt to library" and choose Sample Template.mogrt.
4. Section 3: click Preview (this does not modify the sequence), then Apply.
   Each cue is placed on the selected track with its text filled in.
   A backup of the sequence is created first by default.

--------------------------------------------------------------------
How to test SRT to MOGRT Preflight (free)
--------------------------------------------------------------------
Preflight does NOT load your own SRT. It runs a small fixed set of built-in
captions, using your template, to check compatibility.
1. Open a project that already has a sequence.
2. Add Sample Template.mogrt (Add to library, or "select a .mogrt directly").
3. Run the check. It places the fixed sample captions on a duplicated
   sequence and reports whether the template is compatible.
4. Review the duplicated sequence; your original sequence is left unchanged.
(captions.srt is not used by Preflight.)

Compatibility note
------------------
This template was authored in Adobe Premiere Pro 25.6 and was verified with
Premiere Pro 25.6.6 and 26.3.0 on Windows. A Motion Graphics template carries
a project inside it, so a template exported from a NEWER version of Premiere
Pro cannot be opened by an OLDER one - a limitation of the application, not
the panel.
The panel detects this and explains it in plain language. If you test with
your own template, please use one authored in the same version of Premiere
Pro you are reviewing on, or older.

Support: paneldocktools.contact@gmail.com
